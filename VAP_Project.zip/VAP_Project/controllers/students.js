module.exports=(app,users)=>{
    var load=require('lodash');

    app.get('/students',(req,res)=>{
        if(req.session.user){
            var usr=load.filter(users,(x)=>{ if(x.user==req.session.user) return x})[0];
            var name=usr.name;
            res.render('student-logged',{message:"Welcome  "+name,log:1});
        }
        else{
            res.render('students',{flag:0});
        }
     });

    app.post('/register',(req,res)=>{
        users.push(req.body);
        req.session.user=req.body.user;
        req.session.pass=req.body.pass;
        res.render('student-logged',{message:"Welcome  "+req.session.user,log:1});
    
    });
    

    app.get('/login',(req,res)=>{
        if(req.session.user){
            res.render('student-logged',{message:"Welcome  "+req.session.user,log:1});
        }
        else{
            res.render('students',{flag:1});
        }
    });
    
   
    
    app.post('/login',(req,res)=>{
        //console.log(users);
        var user=req.body.user;
        var pass=req.body.pass;
        var flag=0;
        
        users.forEach(data=>{
            if(user==data.user && pass==data.pass){
                req.session.user=user;
                req.session.pass=pass;
                flag=1
                var usr=load.filter(users,(x)=>{ if(x.user==req.session.user) return x})[0];
                var name=usr.name;
            }
        })
        
        if(flag==1){
            res.render('student-logged',{message:"Welcome  "+req.session.user,log:1});
        }
        else{
            res.render('student-logged',{message:"Username or Password is Incorrect",log:0});
        }
     });

     app.get('/logout',(req,res)=>{

        req.session.destroy(function(err) {
            if(err) {
                console.log(err);
            } else {
                res.redirect('/');
            }
        });

     });
     return users;  
};