module.exports=(app,courses)=>{
    app.get('/teachers',(req,res)=>{
        res.render('teachers');
     });
     
     app.post('/teachers',(req,res)=>{
         courses.push(req.body);
         console.log(req.body);
         res.render('teachers',{message:"Course Added Succesfully",greeting:"Click on this link to see your Courses"});
     });     
     return courses;
}
