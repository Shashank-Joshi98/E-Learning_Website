module.exports=(app,courses)=>{
var path=require('path');
const fs=require('fs');
const util=require('util');
const readFile=util.promisify(fs.readFile);
var load=require('lodash');
var subscribed=[];

app.get('/course-archive.html',(req,res)=>{
    if(req.session.user){
        res.render('course-archive',{data:courses,log:1});       
    }
    else{
        res.render('course-archive',{data:courses,log:2});
    }
});

app.get('/course/:cname',(req,res)=>{
    var course_detail;
    course_detail=load.filter(courses,(x)=>{ if(x.course==req.params.cname) return x})[0];
    const promise=readFile('contents.txt','utf-8');
promise
    .then((file_contents) => res.render('course-single',{data:course_detail,file:file_contents}))
    .catch((err)=> console.log(err))
    .finally(() => console.log('done'))
})

app.get('/add/:cname',(req,res)=>{

    if(req.session.user){
        var course_detail;
        course_detail=load.filter(courses,(x)=>{ if(x.course==req.params.cname) return x})[0];
        subscribed.push(course_detail);
        res.render('course-archive',{data:subscribed,log:0,message:"Course is added Succesfully"});
    }
    else{
        res.sendFile(path.dirname(__dirname)+'/404.html');
    }

});

app.get('/delete/:cname',(req,res)=>{
    if(req.session.user){
        var course_detail;
        course_detail=load.filter(subscribed,(x)=>{ if(x.course==req.params.cname) return x})[0];
        subscribed.splice(subscribed.indexOf(course_detail),1);
        res.render('course-archive',{data:subscribed,log:0});
    }
    else{
        res.sendFile(path.dirname(__dirname)+'/404.html');
    }

});

app.get('/enrolled',(req,res)=>{
    if(req.session.user){
        res.render('course-archive',{data:subscribed,log:0});
    }
    else{
        
        res.render('course-archive',{data:courses,log:0});
    }
});
return courses;
};