var express=require('express');

var session = require('express-session');
var student=require('./controllers/students');
var course=require('./controllers/courses');
var teachers=require('./controllers/teachers');

var app=express();

var courses=[{name:"Shashank",course:"Node-Js",about:"Node js is server side javascript"}];  // This will store an array of objects   

var bodyparser=require('body-parser');

app.use(bodyparser.urlencoded({extended:false}));

app.use(session({secret: 'thisisshank'}));


app.set('view engine','pug');
app.use(express.static('public'));
app.use('/css',express.static('css'));
app.use('/Documentation',express.static('Documentation'));
app.use('/fonts',express.static('fonts'));
app.use('/img',express.static('img'));
app.use('/js',express.static('js'));

app.get('/',(req,res)=>{
    res.sendFile(__dirname+'/index.html');
});

app.get('/index.html',(req,res)=>{
     res.sendFile(__dirname+'/index.html');
});


var users=[{user:"shank",name:"Shashank",pass:1234,id:1}];


courses=course(app,courses,users);


users=student(app,users);

courses=teachers(app,courses);


app.get('/*',(req,res)=>{
    res.sendFile(__dirname+'/404.html');
});


app.listen(3000);  // Listening on Port 3000